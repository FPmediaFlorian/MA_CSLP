gdjs.MainCode = {};
gdjs.MainCode.GDPlayerObjects2_1final = [];

gdjs.MainCode.GDPlayerObjects1= [];
gdjs.MainCode.GDPlayerObjects2= [];
gdjs.MainCode.GDPlayerObjects3= [];
gdjs.MainCode.GDPlayerObjects4= [];
gdjs.MainCode.GDPlayerObjects5= [];
gdjs.MainCode.GDPlayerObjects6= [];
gdjs.MainCode.GDPlatform1Objects1= [];
gdjs.MainCode.GDPlatform1Objects2= [];
gdjs.MainCode.GDPlatform1Objects3= [];
gdjs.MainCode.GDPlatform1Objects4= [];
gdjs.MainCode.GDPlatform1Objects5= [];
gdjs.MainCode.GDPlatform1Objects6= [];
gdjs.MainCode.GDPlatform2Objects1= [];
gdjs.MainCode.GDPlatform2Objects2= [];
gdjs.MainCode.GDPlatform2Objects3= [];
gdjs.MainCode.GDPlatform2Objects4= [];
gdjs.MainCode.GDPlatform2Objects5= [];
gdjs.MainCode.GDPlatform2Objects6= [];
gdjs.MainCode.GDPlatform3Objects1= [];
gdjs.MainCode.GDPlatform3Objects2= [];
gdjs.MainCode.GDPlatform3Objects3= [];
gdjs.MainCode.GDPlatform3Objects4= [];
gdjs.MainCode.GDPlatform3Objects5= [];
gdjs.MainCode.GDPlatform3Objects6= [];
gdjs.MainCode.GDPlatform4Objects1= [];
gdjs.MainCode.GDPlatform4Objects2= [];
gdjs.MainCode.GDPlatform4Objects3= [];
gdjs.MainCode.GDPlatform4Objects4= [];
gdjs.MainCode.GDPlatform4Objects5= [];
gdjs.MainCode.GDPlatform4Objects6= [];
gdjs.MainCode.GDPortalObjects1= [];
gdjs.MainCode.GDPortalObjects2= [];
gdjs.MainCode.GDPortalObjects3= [];
gdjs.MainCode.GDPortalObjects4= [];
gdjs.MainCode.GDPortalObjects5= [];
gdjs.MainCode.GDPortalObjects6= [];
gdjs.MainCode.GDCheckpointObjects1= [];
gdjs.MainCode.GDCheckpointObjects2= [];
gdjs.MainCode.GDCheckpointObjects3= [];
gdjs.MainCode.GDCheckpointObjects4= [];
gdjs.MainCode.GDCheckpointObjects5= [];
gdjs.MainCode.GDCheckpointObjects6= [];
gdjs.MainCode.GDLadderObjects1= [];
gdjs.MainCode.GDLadderObjects2= [];
gdjs.MainCode.GDLadderObjects3= [];
gdjs.MainCode.GDLadderObjects4= [];
gdjs.MainCode.GDLadderObjects5= [];
gdjs.MainCode.GDLadderObjects6= [];
gdjs.MainCode.GDMonsterObjects1= [];
gdjs.MainCode.GDMonsterObjects2= [];
gdjs.MainCode.GDMonsterObjects3= [];
gdjs.MainCode.GDMonsterObjects4= [];
gdjs.MainCode.GDMonsterObjects5= [];
gdjs.MainCode.GDMonsterObjects6= [];
gdjs.MainCode.GDFlyObjects1= [];
gdjs.MainCode.GDFlyObjects2= [];
gdjs.MainCode.GDFlyObjects3= [];
gdjs.MainCode.GDFlyObjects4= [];
gdjs.MainCode.GDFlyObjects5= [];
gdjs.MainCode.GDFlyObjects6= [];
gdjs.MainCode.GDCoinObjects1= [];
gdjs.MainCode.GDCoinObjects2= [];
gdjs.MainCode.GDCoinObjects3= [];
gdjs.MainCode.GDCoinObjects4= [];
gdjs.MainCode.GDCoinObjects5= [];
gdjs.MainCode.GDCoinObjects6= [];
gdjs.MainCode.GDMonsterParticlesObjects1= [];
gdjs.MainCode.GDMonsterParticlesObjects2= [];
gdjs.MainCode.GDMonsterParticlesObjects3= [];
gdjs.MainCode.GDMonsterParticlesObjects4= [];
gdjs.MainCode.GDMonsterParticlesObjects5= [];
gdjs.MainCode.GDMonsterParticlesObjects6= [];
gdjs.MainCode.GDCoinParticlesObjects1= [];
gdjs.MainCode.GDCoinParticlesObjects2= [];
gdjs.MainCode.GDCoinParticlesObjects3= [];
gdjs.MainCode.GDCoinParticlesObjects4= [];
gdjs.MainCode.GDCoinParticlesObjects5= [];
gdjs.MainCode.GDCoinParticlesObjects6= [];
gdjs.MainCode.GDDoorParticlesObjects1= [];
gdjs.MainCode.GDDoorParticlesObjects2= [];
gdjs.MainCode.GDDoorParticlesObjects3= [];
gdjs.MainCode.GDDoorParticlesObjects4= [];
gdjs.MainCode.GDDoorParticlesObjects5= [];
gdjs.MainCode.GDDoorParticlesObjects6= [];
gdjs.MainCode.GDGrassParticleObjects1= [];
gdjs.MainCode.GDGrassParticleObjects2= [];
gdjs.MainCode.GDGrassParticleObjects3= [];
gdjs.MainCode.GDGrassParticleObjects4= [];
gdjs.MainCode.GDGrassParticleObjects5= [];
gdjs.MainCode.GDGrassParticleObjects6= [];
gdjs.MainCode.GDCloudsObjects1= [];
gdjs.MainCode.GDCloudsObjects2= [];
gdjs.MainCode.GDCloudsObjects3= [];
gdjs.MainCode.GDCloudsObjects4= [];
gdjs.MainCode.GDCloudsObjects5= [];
gdjs.MainCode.GDCloudsObjects6= [];
gdjs.MainCode.GDScoreTextObjects1= [];
gdjs.MainCode.GDScoreTextObjects2= [];
gdjs.MainCode.GDScoreTextObjects3= [];
gdjs.MainCode.GDScoreTextObjects4= [];
gdjs.MainCode.GDScoreTextObjects5= [];
gdjs.MainCode.GDScoreTextObjects6= [];
gdjs.MainCode.GDJumpButtonObjects1= [];
gdjs.MainCode.GDJumpButtonObjects2= [];
gdjs.MainCode.GDJumpButtonObjects3= [];
gdjs.MainCode.GDJumpButtonObjects4= [];
gdjs.MainCode.GDJumpButtonObjects5= [];
gdjs.MainCode.GDJumpButtonObjects6= [];
gdjs.MainCode.GDBackgroundPlantsObjects1= [];
gdjs.MainCode.GDBackgroundPlantsObjects2= [];
gdjs.MainCode.GDBackgroundPlantsObjects3= [];
gdjs.MainCode.GDBackgroundPlantsObjects4= [];
gdjs.MainCode.GDBackgroundPlantsObjects5= [];
gdjs.MainCode.GDBackgroundPlantsObjects6= [];
gdjs.MainCode.GDLeftBoundaryObjects1= [];
gdjs.MainCode.GDLeftBoundaryObjects2= [];
gdjs.MainCode.GDLeftBoundaryObjects3= [];
gdjs.MainCode.GDLeftBoundaryObjects4= [];
gdjs.MainCode.GDLeftBoundaryObjects5= [];
gdjs.MainCode.GDLeftBoundaryObjects6= [];
gdjs.MainCode.GDRightBoundaryObjects1= [];
gdjs.MainCode.GDRightBoundaryObjects2= [];
gdjs.MainCode.GDRightBoundaryObjects3= [];
gdjs.MainCode.GDRightBoundaryObjects4= [];
gdjs.MainCode.GDRightBoundaryObjects5= [];
gdjs.MainCode.GDRightBoundaryObjects6= [];
gdjs.MainCode.GDTopBoundaryObjects1= [];
gdjs.MainCode.GDTopBoundaryObjects2= [];
gdjs.MainCode.GDTopBoundaryObjects3= [];
gdjs.MainCode.GDTopBoundaryObjects4= [];
gdjs.MainCode.GDTopBoundaryObjects5= [];
gdjs.MainCode.GDTopBoundaryObjects6= [];
gdjs.MainCode.GDBottomBoundaryObjects1= [];
gdjs.MainCode.GDBottomBoundaryObjects2= [];
gdjs.MainCode.GDBottomBoundaryObjects3= [];
gdjs.MainCode.GDBottomBoundaryObjects4= [];
gdjs.MainCode.GDBottomBoundaryObjects5= [];
gdjs.MainCode.GDBottomBoundaryObjects6= [];
gdjs.MainCode.GDBoundaryJumpThroughObjects1= [];
gdjs.MainCode.GDBoundaryJumpThroughObjects2= [];
gdjs.MainCode.GDBoundaryJumpThroughObjects3= [];
gdjs.MainCode.GDBoundaryJumpThroughObjects4= [];
gdjs.MainCode.GDBoundaryJumpThroughObjects5= [];
gdjs.MainCode.GDBoundaryJumpThroughObjects6= [];
gdjs.MainCode.GDMoonObjects1= [];
gdjs.MainCode.GDMoonObjects2= [];
gdjs.MainCode.GDMoonObjects3= [];
gdjs.MainCode.GDMoonObjects4= [];
gdjs.MainCode.GDMoonObjects5= [];
gdjs.MainCode.GDMoonObjects6= [];
gdjs.MainCode.GDEndScreenBackgroundObjects1= [];
gdjs.MainCode.GDEndScreenBackgroundObjects2= [];
gdjs.MainCode.GDEndScreenBackgroundObjects3= [];
gdjs.MainCode.GDEndScreenBackgroundObjects4= [];
gdjs.MainCode.GDEndScreenBackgroundObjects5= [];
gdjs.MainCode.GDEndScreenBackgroundObjects6= [];
gdjs.MainCode.GDEndScreenHeaderObjects1= [];
gdjs.MainCode.GDEndScreenHeaderObjects2= [];
gdjs.MainCode.GDEndScreenHeaderObjects3= [];
gdjs.MainCode.GDEndScreenHeaderObjects4= [];
gdjs.MainCode.GDEndScreenHeaderObjects5= [];
gdjs.MainCode.GDEndScreenHeaderObjects6= [];
gdjs.MainCode.GDEndScreenSubHeaderObjects1= [];
gdjs.MainCode.GDEndScreenSubHeaderObjects2= [];
gdjs.MainCode.GDEndScreenSubHeaderObjects3= [];
gdjs.MainCode.GDEndScreenSubHeaderObjects4= [];
gdjs.MainCode.GDEndScreenSubHeaderObjects5= [];
gdjs.MainCode.GDEndScreenSubHeaderObjects6= [];
gdjs.MainCode.GDEndScreenBestTextObjects1= [];
gdjs.MainCode.GDEndScreenBestTextObjects2= [];
gdjs.MainCode.GDEndScreenBestTextObjects3= [];
gdjs.MainCode.GDEndScreenBestTextObjects4= [];
gdjs.MainCode.GDEndScreenBestTextObjects5= [];
gdjs.MainCode.GDEndScreenBestTextObjects6= [];
gdjs.MainCode.GDEndScreenChallengeTextObjects1= [];
gdjs.MainCode.GDEndScreenChallengeTextObjects2= [];
gdjs.MainCode.GDEndScreenChallengeTextObjects3= [];
gdjs.MainCode.GDEndScreenChallengeTextObjects4= [];
gdjs.MainCode.GDEndScreenChallengeTextObjects5= [];
gdjs.MainCode.GDEndScreenChallengeTextObjects6= [];
gdjs.MainCode.GDEndScreenRetryTextObjects1= [];
gdjs.MainCode.GDEndScreenRetryTextObjects2= [];
gdjs.MainCode.GDEndScreenRetryTextObjects3= [];
gdjs.MainCode.GDEndScreenRetryTextObjects4= [];
gdjs.MainCode.GDEndScreenRetryTextObjects5= [];
gdjs.MainCode.GDEndScreenRetryTextObjects6= [];
gdjs.MainCode.GDJoystickThumbObjects1= [];
gdjs.MainCode.GDJoystickThumbObjects2= [];
gdjs.MainCode.GDJoystickThumbObjects3= [];
gdjs.MainCode.GDJoystickThumbObjects4= [];
gdjs.MainCode.GDJoystickThumbObjects5= [];
gdjs.MainCode.GDJoystickThumbObjects6= [];
gdjs.MainCode.GDJoystickObjects1= [];
gdjs.MainCode.GDJoystickObjects2= [];
gdjs.MainCode.GDJoystickObjects3= [];
gdjs.MainCode.GDJoystickObjects4= [];
gdjs.MainCode.GDJoystickObjects5= [];
gdjs.MainCode.GDJoystickObjects6= [];

gdjs.MainCode.conditionTrue_0 = {val:false};
gdjs.MainCode.condition0IsTrue_0 = {val:false};
gdjs.MainCode.condition1IsTrue_0 = {val:false};
gdjs.MainCode.condition2IsTrue_0 = {val:false};
gdjs.MainCode.condition3IsTrue_0 = {val:false};
gdjs.MainCode.conditionTrue_1 = {val:false};
gdjs.MainCode.condition0IsTrue_1 = {val:false};
gdjs.MainCode.condition1IsTrue_1 = {val:false};
gdjs.MainCode.condition2IsTrue_1 = {val:false};
gdjs.MainCode.condition3IsTrue_1 = {val:false};


gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDJoystickThumbObjects3Objects = Hashtable.newFrom({"JoystickThumb": gdjs.MainCode.GDJoystickThumbObjects3});
gdjs.MainCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainCode.GDJoystickObjects4, gdjs.MainCode.GDJoystickObjects5);


gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDJoystickObjects5.length;i<l;++i) {
    if ( gdjs.MainCode.GDJoystickObjects5[i].getBehavior("MultitouchJoystick").DirectionPushed("Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDJoystickObjects5[k] = gdjs.MainCode.GDJoystickObjects5[i];
        ++k;
    }
}
gdjs.MainCode.GDJoystickObjects5.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects5);
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects5[i].getBehavior("PlatformerObject").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(gdjs.MainCode.GDJoystickObjects4, gdjs.MainCode.GDJoystickObjects5);


gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDJoystickObjects5.length;i<l;++i) {
    if ( gdjs.MainCode.GDJoystickObjects5[i].getBehavior("MultitouchJoystick").DirectionPushed("Right", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDJoystickObjects5[k] = gdjs.MainCode.GDJoystickObjects5[i];
        ++k;
    }
}
gdjs.MainCode.GDJoystickObjects5.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects5);
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects5[i].getBehavior("PlatformerObject").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(gdjs.MainCode.GDJoystickObjects4, gdjs.MainCode.GDJoystickObjects5);


gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDJoystickObjects5.length;i<l;++i) {
    if ( gdjs.MainCode.GDJoystickObjects5[i].getBehavior("MultitouchJoystick").DirectionPushed("Up", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDJoystickObjects5[k] = gdjs.MainCode.GDJoystickObjects5[i];
        ++k;
    }
}
gdjs.MainCode.GDJoystickObjects5.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects5);
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects5[i].getBehavior("PlatformerObject").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects5[i].getBehavior("PlatformerObject").simulateControl("Ladder");
}
}}

}


{

/* Reuse gdjs.MainCode.GDJoystickObjects4 */

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDJoystickObjects4.length;i<l;++i) {
    if ( gdjs.MainCode.GDJoystickObjects4[i].getBehavior("MultitouchJoystick").DirectionPushed("Down", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDJoystickObjects4[k] = gdjs.MainCode.GDJoystickObjects4[i];
        ++k;
    }
}
gdjs.MainCode.GDJoystickObjects4.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects4);
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects4[i].getBehavior("PlatformerObject").simulateControl("Down");
}
}}

}


};gdjs.MainCode.eventsList1 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.MainCode.GDJoystickObjects3, gdjs.MainCode.GDJoystickObjects4);


gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDJoystickObjects4.length;i<l;++i) {
    if ( gdjs.MainCode.GDJoystickObjects4[i].getBehavior("MultitouchJoystick").CheckJoystickForce(0.4, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDJoystickObjects4[k] = gdjs.MainCode.GDJoystickObjects4[i];
        ++k;
    }
}
gdjs.MainCode.GDJoystickObjects4.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList0(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.MainCode.GDJumpButtonObjects4);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDJumpButtonObjects4.length;i<l;++i) {
    if ( gdjs.MainCode.GDJumpButtonObjects4[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDJumpButtonObjects4[k] = gdjs.MainCode.GDJumpButtonObjects4[i];
        ++k;
    }
}
gdjs.MainCode.GDJumpButtonObjects4.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDJumpButtonObjects4 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects4);
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects4[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}{for(var i = 0, len = gdjs.MainCode.GDJumpButtonObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDJumpButtonObjects4[i].setColor("74;74;74");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.MainCode.GDJumpButtonObjects3);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDJumpButtonObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDJumpButtonObjects3[i].getBehavior("MultitouchButton").IsReleased((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDJumpButtonObjects3[k] = gdjs.MainCode.GDJumpButtonObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDJumpButtonObjects3.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDJumpButtonObjects3 */
{for(var i = 0, len = gdjs.MainCode.GDJumpButtonObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDJumpButtonObjects3[i].setColor("255;255;255");
}
}}

}


};gdjs.MainCode.eventsList2 = function(runtimeScene) {

{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
{gdjs.evtTools.input.touchSimulateMouse(runtimeScene, false);
}}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.MainCode.GDJoystickObjects3);
gdjs.copyArray(runtimeScene.getObjects("JoystickThumb"), gdjs.MainCode.GDJoystickThumbObjects3);
{for(var i = 0, len = gdjs.MainCode.GDJoystickObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDJoystickObjects3[i].getBehavior("MultitouchJoystick").ActivateJoystick(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDJoystickThumbObjects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.MainCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.MainCode.GDJoystickObjects2);
gdjs.copyArray(runtimeScene.getObjects("JoystickThumb"), gdjs.MainCode.GDJoystickThumbObjects2);
gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.MainCode.GDJumpButtonObjects2);
{for(var i = 0, len = gdjs.MainCode.GDJumpButtonObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDJumpButtonObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.MainCode.GDJoystickObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDJoystickObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.MainCode.GDJoystickThumbObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDJoystickThumbObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.MainCode.eventsList3 = function(runtimeScene) {

{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtsExt__Gamepads__C_Axis_pushed.func(runtimeScene, 1, "LEFT", "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Left");
}
}}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtsExt__Gamepads__C_Axis_pushed.func(runtimeScene, 1, "LEFT", "Right", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Right");
}
}}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtsExt__Gamepads__C_Axis_pushed.func(runtimeScene, 1, "LEFT", "Up", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Ladder");
}
}}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtsExt__Gamepads__C_Axis_pushed.func(runtimeScene, 1, "LEFT", "Down", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Down");
}
}}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtsExt__Gamepads__C_Any_Button_pressed.func(runtimeScene, 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}}

}


};gdjs.MainCode.eventsList4 = function(runtimeScene) {

{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtsExt__Gamepads__C_Controller_X_is_connected.func(runtimeScene, 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.MainCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.eventsList5 = function(runtimeScene) {

{



}


{


gdjs.MainCode.eventsList2(runtimeScene);
}


{


gdjs.MainCode.eventsList4(runtimeScene);
}


};gdjs.MainCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainCode.GDPlayerObjects3, gdjs.MainCode.GDPlayerObjects4);


gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects4[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects4[k] = gdjs.MainCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects4.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12125220);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects4[i].setAnimationName("Jump");
}
}}

}


{

gdjs.copyArray(gdjs.MainCode.GDPlayerObjects3, gdjs.MainCode.GDPlayerObjects4);


gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects4[i].getBehavior("PlatformerObject").isOnLadder() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects4[k] = gdjs.MainCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects4.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12125660);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects4[i].setAnimationName("Climb");
}
}{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects4[i].playAnimation();
}
}}

}


{

gdjs.copyArray(gdjs.MainCode.GDPlayerObjects3, gdjs.MainCode.GDPlayerObjects4);


gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects4[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects4[k] = gdjs.MainCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects4.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12126604);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects4[i].setAnimationName("Run");
}
}}

}


{

/* Reuse gdjs.MainCode.GDPlayerObjects3 */

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects3[k] = gdjs.MainCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects3.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12127412);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects3[i].setAnimationName("Fall");
}
}}

}


};gdjs.MainCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainCode.GDPlayerObjects2, gdjs.MainCode.GDPlayerObjects3);


gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").isOnLadder() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects3[k] = gdjs.MainCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects3.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12128996);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects3[i].pauseAnimation();
}
}}

}


{

/* Reuse gdjs.MainCode.GDPlayerObjects2 */

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12129372);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].setAnimationName("Idle");
}
}}

}


};gdjs.MainCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects3);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").isMoving() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects3[k] = gdjs.MainCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects3.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects3);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects3[k] = gdjs.MainCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects3.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12130284);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects3[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12131396);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].flipX(false);
}
}}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDGrassParticleObjects2Objects = Hashtable.newFrom({"GrassParticle": gdjs.MainCode.GDGrassParticleObjects2});
gdjs.MainCode.eventsList10 = function(runtimeScene) {

{



}


{

/* Reuse gdjs.MainCode.GDPlayerObjects2 */

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition0IsTrue_0;
gdjs.MainCode.GDPlayerObjects2_1final.length = 0;gdjs.MainCode.condition0IsTrue_1.val = false;
gdjs.MainCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.MainCode.GDPlayerObjects2, gdjs.MainCode.GDPlayerObjects3);

for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects3[i].getAnimationFrame() == 4 ) {
        gdjs.MainCode.condition0IsTrue_1.val = true;
        gdjs.MainCode.GDPlayerObjects3[k] = gdjs.MainCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects3.length = k;if( gdjs.MainCode.condition0IsTrue_1.val ) {
    gdjs.MainCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainCode.GDPlayerObjects3.length;j<jLen;++j) {
        if ( gdjs.MainCode.GDPlayerObjects2_1final.indexOf(gdjs.MainCode.GDPlayerObjects3[j]) === -1 )
            gdjs.MainCode.GDPlayerObjects2_1final.push(gdjs.MainCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainCode.GDPlayerObjects2, gdjs.MainCode.GDPlayerObjects3);

for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects3[i].getAnimationFrame() == 14 ) {
        gdjs.MainCode.condition1IsTrue_1.val = true;
        gdjs.MainCode.GDPlayerObjects3[k] = gdjs.MainCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects3.length = k;if( gdjs.MainCode.condition1IsTrue_1.val ) {
    gdjs.MainCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainCode.GDPlayerObjects3.length;j<jLen;++j) {
        if ( gdjs.MainCode.GDPlayerObjects2_1final.indexOf(gdjs.MainCode.GDPlayerObjects3[j]) === -1 )
            gdjs.MainCode.GDPlayerObjects2_1final.push(gdjs.MainCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainCode.GDPlayerObjects2_1final, gdjs.MainCode.GDPlayerObjects2);
}
}
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12134916);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects2 */
gdjs.MainCode.GDGrassParticleObjects2.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets/audio/grass.mp3", 1, false, 20, gdjs.randomFloatInRange(0.7, 1.2));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDGrassParticleObjects2Objects, (( gdjs.MainCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDPlayerObjects2[0].getPointX("GrassParticle")), (( gdjs.MainCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDPlayerObjects2[0].getPointY("GrassParticle")), "");
}{for(var i = 0, len = gdjs.MainCode.GDGrassParticleObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDGrassParticleObjects2[i].setZOrder(-(1));
}
}}

}


};gdjs.MainCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects3);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects3[k] = gdjs.MainCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects3.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12132604);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "jump.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects2[i].isCurrentAnimationName("Run") ) {
        gdjs.MainCode.condition1IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;}}
if (gdjs.MainCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects3});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDCheckpointObjects2Objects = Hashtable.newFrom({"Checkpoint": gdjs.MainCode.GDCheckpointObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDCheckpointObjects3Objects = Hashtable.newFrom({"Checkpoint": gdjs.MainCode.GDCheckpointObjects3});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects2});
gdjs.MainCode.eventsList12 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.MainCode.GDCheckpointObjects2, gdjs.MainCode.GDCheckpointObjects3);


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickAllObjects(runtimeScene, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDCheckpointObjects3Objects);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDCheckpointObjects3 */
{for(var i = 0, len = gdjs.MainCode.GDCheckpointObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCheckpointObjects3[i].setEffectDoubleParameter("Gray", "saturation", 0);
}
}{for(var i = 0, len = gdjs.MainCode.GDCheckpointObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDCheckpointObjects3[i].setAnimationName("InActive");
}
}}

}


{



}


{


{
/* Reuse gdjs.MainCode.GDCheckpointObjects2 */
/* Reuse gdjs.MainCode.GDPlayerObjects2 */
{gdjs.evtsExt__Checkpoints__SaveCheckpoint.func(runtimeScene, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects, (( gdjs.MainCode.GDCheckpointObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDCheckpointObjects2[0].getPointX("")), (( gdjs.MainCode.GDCheckpointObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDCheckpointObjects2[0].getPointY("")), "Checkpoint", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.MainCode.GDCheckpointObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDCheckpointObjects2[i].setEffectDoubleParameter("Gray", "saturation", 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDCheckpointObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDCheckpointObjects2[i].setAnimationName("Activate");
}
}}

}


};gdjs.MainCode.eventsList13 = function(runtimeScene) {

{



}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects3);
{gdjs.evtsExt__Checkpoints__SaveCheckpoint.func(runtimeScene, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects3Objects, (( gdjs.MainCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.MainCode.GDPlayerObjects3[0].getPointX("")), (( gdjs.MainCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.MainCode.GDPlayerObjects3[0].getPointY("")), "Checkpoint", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Checkpoint"), gdjs.MainCode.GDCheckpointObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
gdjs.MainCode.condition2IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDCheckpointObjects2Objects, false, runtimeScene, false);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDCheckpointObjects2.length;i<l;++i) {
    if ( !(gdjs.MainCode.GDCheckpointObjects2[i].isCurrentAnimationName("Activate")) ) {
        gdjs.MainCode.condition1IsTrue_0.val = true;
        gdjs.MainCode.GDCheckpointObjects2[k] = gdjs.MainCode.GDCheckpointObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDCheckpointObjects2.length = k;}if ( gdjs.MainCode.condition1IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition2IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12137932);
}
}}
}
if (gdjs.MainCode.condition2IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "checkpoint.mp3", false, 50, 1);
}
{ //Subevents
gdjs.MainCode.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.MainCode.GDCoinObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDCoinParticlesObjects2Objects = Hashtable.newFrom({"CoinParticles": gdjs.MainCode.GDCoinParticlesObjects2});
gdjs.MainCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.MainCode.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDCoinObjects2Objects, false, runtimeScene, false);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12141092);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDCoinObjects2 */
gdjs.MainCode.GDCoinParticlesObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDCoinParticlesObjects2Objects, (( gdjs.MainCode.GDCoinObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDCoinObjects2[0].getCenterXInScene()), (( gdjs.MainCode.GDCoinObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDCoinObjects2[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.MainCode.GDCoinObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDCoinObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().getFromIndex(0).add(100);
}{gdjs.evtTools.sound.playSound(runtimeScene, "coin.mp3", false, 50, 1);
}}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects1});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects1});
gdjs.MainCode.eventsList15 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("BackgroundPlants"), gdjs.MainCode.GDBackgroundPlantsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects2[i].getY() > (( gdjs.MainCode.GDBackgroundPlantsObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDBackgroundPlantsObjects2[0].getAABBBottom()) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12142948);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].setVariableBoolean(gdjs.MainCode.GDPlayerObjects2[i].getVariables().getFromIndex(0), true);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects1[i].getVariableBoolean(gdjs.MainCode.GDPlayerObjects1[i].getVariables().getFromIndex(0), true) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects1[k] = gdjs.MainCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects1.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12144436);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects1[i].setVariableBoolean(gdjs.MainCode.GDPlayerObjects1[i].getVariables().getFromIndex(0), false);
}
}{gdjs.evtsExt__Checkpoints__LoadCheckpoint.func(runtimeScene, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects1Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects1Objects, "Checkpoint", false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.sound.playSound(runtimeScene, "death.mp3", false, 50, 1);
}}

}


};gdjs.MainCode.eventsList16 = function(runtimeScene) {

{


gdjs.MainCode.eventsList8(runtimeScene);
}


{


gdjs.MainCode.eventsList9(runtimeScene);
}


{


gdjs.MainCode.eventsList11(runtimeScene);
}


{


gdjs.MainCode.eventsList13(runtimeScene);
}


{


gdjs.MainCode.eventsList14(runtimeScene);
}


{


gdjs.MainCode.eventsList15(runtimeScene);
}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDMonsterObjects2Objects = Hashtable.newFrom({"Monster": gdjs.MainCode.GDMonsterObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDMonsterParticlesObjects4Objects = Hashtable.newFrom({"MonsterParticles": gdjs.MainCode.GDMonsterParticlesObjects4});
gdjs.MainCode.eventsList17 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.MainCode.GDPlayerObjects2, gdjs.MainCode.GDPlayerObjects4);


gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects4[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects4[k] = gdjs.MainCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects4.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainCode.GDMonsterObjects3, gdjs.MainCode.GDMonsterObjects4);

/* Reuse gdjs.MainCode.GDPlayerObjects4 */
gdjs.MainCode.GDMonsterParticlesObjects4.length = 0;

{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects4[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects4[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{runtimeScene.getVariables().getFromIndex(0).add(50);
}{for(var i = 0, len = gdjs.MainCode.GDMonsterObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDMonsterObjects4[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "jump.mp3", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)), 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDMonsterParticlesObjects4Objects, (( gdjs.MainCode.GDMonsterObjects4.length === 0 ) ? 0 :gdjs.MainCode.GDMonsterObjects4[0].getCenterXInScene()), (( gdjs.MainCode.GDMonsterObjects4.length === 0 ) ? 0 :gdjs.MainCode.GDMonsterObjects4[0].getCenterYInScene()), "");
}}

}


{



}


{

gdjs.copyArray(gdjs.MainCode.GDPlayerObjects2, gdjs.MainCode.GDPlayerObjects3);


gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.MainCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").isFalling()) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects3[k] = gdjs.MainCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects3.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects3[i].setVariableBoolean(gdjs.MainCode.GDPlayerObjects3[i].getVariables().getFromIndex(0), true);
}
}}

}


};gdjs.MainCode.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainCode.GDMonsterObjects2, gdjs.MainCode.GDMonsterObjects3);


gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDMonsterObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDMonsterObjects3[i].isCurrentAnimationName("NoFire") ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDMonsterObjects3[k] = gdjs.MainCode.GDMonsterObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDMonsterObjects3.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList17(runtimeScene);} //End of subevents
}

}


{



}


{

/* Reuse gdjs.MainCode.GDMonsterObjects2 */

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDMonsterObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDMonsterObjects2[i].isCurrentAnimationName("Fire") ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDMonsterObjects2[k] = gdjs.MainCode.GDMonsterObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDMonsterObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].setVariableBoolean(gdjs.MainCode.GDPlayerObjects2[i].getVariables().getFromIndex(0), true);
}
}}

}


};gdjs.MainCode.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.MainCode.GDMonsterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDMonsterObjects2Objects, false, runtimeScene, false);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12145804);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.eventsList20 = function(runtimeScene) {

{



}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.MainCode.GDMonsterObjects3);
{for(var i = 0, len = gdjs.MainCode.GDMonsterObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDMonsterObjects3[i].resetTimer("Fire");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.MainCode.GDMonsterObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDMonsterObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDMonsterObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Fire") >= 2 ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDMonsterObjects2[k] = gdjs.MainCode.GDMonsterObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDMonsterObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDMonsterObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDMonsterObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDMonsterObjects2[i].toggleVariableBoolean(gdjs.MainCode.GDMonsterObjects2[i].getVariables().getFromIndex(0));
}
}{for(var i = 0, len = gdjs.MainCode.GDMonsterObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDMonsterObjects2[i].resetTimer("Fire");
}
}}

}


};gdjs.MainCode.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.MainCode.GDMonsterObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDMonsterObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDMonsterObjects2[i].getVariableBoolean(gdjs.MainCode.GDMonsterObjects2[i].getVariables().getFromIndex(0), false) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDMonsterObjects2[k] = gdjs.MainCode.GDMonsterObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDMonsterObjects2.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12153644);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDMonsterObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDMonsterObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDMonsterObjects2[i].setAnimationName("NoFire");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.MainCode.GDMonsterObjects1);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDMonsterObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDMonsterObjects1[i].getVariableBoolean(gdjs.MainCode.GDMonsterObjects1[i].getVariables().getFromIndex(0), true) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDMonsterObjects1[k] = gdjs.MainCode.GDMonsterObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDMonsterObjects1.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12154084);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDMonsterObjects1 */
{for(var i = 0, len = gdjs.MainCode.GDMonsterObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDMonsterObjects1[i].setAnimationName("Fire");
}
}}

}


};gdjs.MainCode.eventsList22 = function(runtimeScene) {

{


gdjs.MainCode.eventsList20(runtimeScene);
}


{


gdjs.MainCode.eventsList21(runtimeScene);
}


};gdjs.MainCode.eventsList23 = function(runtimeScene) {

{


gdjs.MainCode.eventsList19(runtimeScene);
}


{


gdjs.MainCode.eventsList22(runtimeScene);
}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDFlyObjects2Objects = Hashtable.newFrom({"Fly": gdjs.MainCode.GDFlyObjects2});
gdjs.MainCode.eventsList24 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(gdjs.MainCode.GDPlayerObjects3, gdjs.MainCode.GDPlayerObjects4);

{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects4[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects4[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "jump.mp3", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)), 1);
}}

}


{



}


{


{
{runtimeScene.getVariables().getFromIndex(0).add(50);
}}

}


{



}


{


{
/* Reuse gdjs.MainCode.GDFlyObjects3 */
{for(var i = 0, len = gdjs.MainCode.GDFlyObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDFlyObjects3[i].activateBehavior("RectangularMovement", false);
}
}{for(var i = 0, len = gdjs.MainCode.GDFlyObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDFlyObjects3[i].addPolarForce(90, 150, 1);
}
}{for(var i = 0, len = gdjs.MainCode.GDFlyObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDFlyObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(300, 0, 0, 30, 0.3, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.MainCode.eventsList25 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.MainCode.GDPlayerObjects2, gdjs.MainCode.GDPlayerObjects3);


gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects3[k] = gdjs.MainCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects3.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainCode.GDFlyObjects2, gdjs.MainCode.GDFlyObjects3);

{for(var i = 0, len = gdjs.MainCode.GDFlyObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDFlyObjects3[i].setVariableBoolean(gdjs.MainCode.GDFlyObjects3[i].getVariables().getFromIndex(0), true);
}
}
{ //Subevents
gdjs.MainCode.eventsList24(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.eventsList26 = function(runtimeScene) {

{

/* Reuse gdjs.MainCode.GDPlayerObjects2 */

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isFalling()) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].setVariableBoolean(gdjs.MainCode.GDPlayerObjects2[i].getVariables().getFromIndex(0), true);
}
}}

}


};gdjs.MainCode.eventsList27 = function(runtimeScene) {

{


gdjs.MainCode.eventsList25(runtimeScene);
}


{


gdjs.MainCode.eventsList26(runtimeScene);
}


};gdjs.MainCode.eventsList28 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs.MainCode.GDFlyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
gdjs.MainCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDFlyObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDFlyObjects2[i].getVariableBoolean(gdjs.MainCode.GDFlyObjects2[i].getVariables().getFromIndex(0), false) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDFlyObjects2[k] = gdjs.MainCode.GDFlyObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDFlyObjects2.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
gdjs.MainCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDFlyObjects2Objects, false, runtimeScene, false);
}if ( gdjs.MainCode.condition1IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition2IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12155668);
}
}}
}
if (gdjs.MainCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList27(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.eventsList29 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("BackgroundPlants"), gdjs.MainCode.GDBackgroundPlantsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs.MainCode.GDFlyObjects1);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDFlyObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDFlyObjects1[i].getY() > (( gdjs.MainCode.GDBackgroundPlantsObjects1.length === 0 ) ? 0 :gdjs.MainCode.GDBackgroundPlantsObjects1[0].getAABBBottom()) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDFlyObjects1[k] = gdjs.MainCode.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDFlyObjects1.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12161916);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDFlyObjects1 */
{for(var i = 0, len = gdjs.MainCode.GDFlyObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDFlyObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.MainCode.eventsList30 = function(runtimeScene) {

{


gdjs.MainCode.eventsList28(runtimeScene);
}


{


gdjs.MainCode.eventsList29(runtimeScene);
}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPortalObjects2Objects = Hashtable.newFrom({"Portal": gdjs.MainCode.GDPortalObjects2});
gdjs.MainCode.eventsList31 = function(runtimeScene) {

{



}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition0IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12166348);
}
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.MainCode.GDPortalObjects3);
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects3[i].activateBehavior("PlatformerObject", false);
}
}{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects3[i].getBehavior("Tween").addObjectPositionTween("MoveIntoPortal", (( gdjs.MainCode.GDPortalObjects3.length === 0 ) ? 0 :gdjs.MainCode.GDPortalObjects3[0].getCenterXInScene()) + (gdjs.MainCode.GDPlayerObjects3[i].getWidth()) / 2, (( gdjs.MainCode.GDPortalObjects3.length === 0 ) ? 0 :gdjs.MainCode.GDPortalObjects3[0].getCenterYInScene()), "linear", 1000, false);
}
}{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects3[i].getBehavior("Tween").addObjectAngleTween("RotateIntoPortal", 360, "linear", 1000, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects2[i].getBehavior("Tween").hasFinished("RotateIntoPortal") ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12168244);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].getBehavior("Tween").addObjectScaleTween("ShrinkIntoPortal", 0, 0, "linear", 1000, false, true);
}
}}

}


};gdjs.MainCode.eventsList32 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("EndScreenSubHeader"), gdjs.MainCode.GDEndScreenSubHeaderObjects4);
{for(var i = 0, len = gdjs.MainCode.GDEndScreenSubHeaderObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDEndScreenSubHeaderObjects4[i].setString("You got " + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(0)) + " points!");
}
}}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) < 950;
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EndScreenBestText"), gdjs.MainCode.GDEndScreenBestTextObjects4);
{for(var i = 0, len = gdjs.MainCode.GDEndScreenBestTextObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDEndScreenBestTextObjects4[i].hide();
}
}}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) >= 950;
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EndScreenChallengeText"), gdjs.MainCode.GDEndScreenChallengeTextObjects3);
{for(var i = 0, len = gdjs.MainCode.GDEndScreenChallengeTextObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDEndScreenChallengeTextObjects3[i].hide();
}
}}

}


};gdjs.MainCode.eventsList33 = function(runtimeScene) {

{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition0IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12169028);
}
}if (gdjs.MainCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList32(runtimeScene);} //End of subevents
}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("EndScreenBackground"), gdjs.MainCode.GDEndScreenBackgroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenBestText"), gdjs.MainCode.GDEndScreenBestTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenChallengeText"), gdjs.MainCode.GDEndScreenChallengeTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenHeader"), gdjs.MainCode.GDEndScreenHeaderObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenRetryText"), gdjs.MainCode.GDEndScreenRetryTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenSubHeader"), gdjs.MainCode.GDEndScreenSubHeaderObjects2);
{for(var i = 0, len = gdjs.MainCode.GDEndScreenBackgroundObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDEndScreenBackgroundObjects2[i].setWidth(gdjs.evtTools.camera.getCameraWidth(runtimeScene, "EndScreen", 0));
}
}{for(var i = 0, len = gdjs.MainCode.GDEndScreenBackgroundObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDEndScreenBackgroundObjects2[i].setHeight(gdjs.evtTools.camera.getCameraHeight(runtimeScene, "EndScreen", 0));
}
}{for(var i = 0, len = gdjs.MainCode.GDEndScreenBackgroundObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDEndScreenBackgroundObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.MainCode.GDEndScreenHeaderObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDEndScreenHeaderObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.MainCode.GDEndScreenSubHeaderObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDEndScreenSubHeaderObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.MainCode.GDEndScreenBestTextObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDEndScreenBestTextObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.MainCode.GDEndScreenChallengeTextObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDEndScreenChallengeTextObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.MainCode.GDEndScreenRetryTextObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDEndScreenRetryTextObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
}}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDEndScreenRetryTextObjects2Objects = Hashtable.newFrom({"EndScreenRetryText": gdjs.MainCode.GDEndScreenRetryTextObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDEndScreenRetryTextObjects2Objects = Hashtable.newFrom({"EndScreenRetryText": gdjs.MainCode.GDEndScreenRetryTextObjects2});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDEndScreenRetryTextObjects1Objects = Hashtable.newFrom({"EndScreenRetryText": gdjs.MainCode.GDEndScreenRetryTextObjects1});
gdjs.MainCode.eventsList34 = function(runtimeScene) {

{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition0IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12173196);
}
}if (gdjs.MainCode.condition0IsTrue_0.val) {
{gdjs.evtTools.input.touchSimulateMouse(runtimeScene, true);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("EndScreenRetryText"), gdjs.MainCode.GDEndScreenRetryTextObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDEndScreenRetryTextObjects2Objects, runtimeScene, true, false);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12173996);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDEndScreenRetryTextObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDEndScreenRetryTextObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDEndScreenRetryTextObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 0, 0, 10, 0.2, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("EndScreenRetryText"), gdjs.MainCode.GDEndScreenRetryTextObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDEndScreenRetryTextObjects2Objects, runtimeScene, true, true);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12174924);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDEndScreenRetryTextObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDEndScreenRetryTextObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDEndScreenRetryTextObjects2[i].getBehavior("ShakeObject_PositionAngle").StopShaking((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("EndScreenRetryText"), gdjs.MainCode.GDEndScreenRetryTextObjects1);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDEndScreenRetryTextObjects1Objects, runtimeScene, true, false);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
gdjs.MainCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), false);
}}

}


};gdjs.MainCode.eventsList35 = function(runtimeScene) {

{


gdjs.MainCode.eventsList31(runtimeScene);
}


{


gdjs.MainCode.eventsList33(runtimeScene);
}


{


gdjs.MainCode.eventsList34(runtimeScene);
}


};gdjs.MainCode.eventsList36 = function(runtimeScene) {

{



}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EndScreenBackground"), gdjs.MainCode.GDEndScreenBackgroundObjects2);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "EndScreen");
}{for(var i = 0, len = gdjs.MainCode.GDEndScreenBackgroundObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDEndScreenBackgroundObjects2[i].setOpacity(130);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.MainCode.GDPortalObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPortalObjects2Objects, false, runtimeScene, false);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12164348);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "EndScreen");
}}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "EndScreen");
}if (gdjs.MainCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList35(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.eventsList37 = function(runtimeScene) {

{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("BoundaryJumpThrough"), gdjs.MainCode.GDBoundaryJumpThroughObjects3);
gdjs.copyArray(runtimeScene.getObjects("LeftBoundary"), gdjs.MainCode.GDLeftBoundaryObjects3);
gdjs.copyArray(runtimeScene.getObjects("RightBoundary"), gdjs.MainCode.GDRightBoundaryObjects3);
{for(var i = 0, len = gdjs.MainCode.GDLeftBoundaryObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDLeftBoundaryObjects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDRightBoundaryObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDRightBoundaryObjects3[i].hide();
}
for(var i = 0, len = gdjs.MainCode.GDBoundaryJumpThroughObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDBoundaryJumpThroughObjects3[i].hide();
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("BottomBoundary"), gdjs.MainCode.GDBottomBoundaryObjects2);
gdjs.copyArray(runtimeScene.getObjects("LeftBoundary"), gdjs.MainCode.GDLeftBoundaryObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightBoundary"), gdjs.MainCode.GDRightBoundaryObjects2);
gdjs.copyArray(runtimeScene.getObjects("TopBoundary"), gdjs.MainCode.GDTopBoundaryObjects2);
{gdjs.evtTools.camera.clampCamera(runtimeScene, (( gdjs.MainCode.GDLeftBoundaryObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDLeftBoundaryObjects2[0].getPointX("")) + (( gdjs.MainCode.GDLeftBoundaryObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDLeftBoundaryObjects2[0].getWidth()), (( gdjs.MainCode.GDTopBoundaryObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDTopBoundaryObjects2[0].getPointY("")) + (( gdjs.MainCode.GDTopBoundaryObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDTopBoundaryObjects2[0].getHeight()), (( gdjs.MainCode.GDRightBoundaryObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDRightBoundaryObjects2[0].getPointX("")), (( gdjs.MainCode.GDBottomBoundaryObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDBottomBoundaryObjects2[0].getPointY("")), "", 0);
}}

}


};gdjs.MainCode.eventsList38 = function(runtimeScene) {

{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "crickets.aac", true, 30, 1);
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("BackgroundPlants"), gdjs.MainCode.GDBackgroundPlantsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Clouds"), gdjs.MainCode.GDCloudsObjects2);
{for(var i = 0, len = gdjs.MainCode.GDBackgroundPlantsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDBackgroundPlantsObjects2[i].setWidth(gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.MainCode.GDBackgroundPlantsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDBackgroundPlantsObjects2[i].setXOffset(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) / 3 + 621);
}
}{for(var i = 0, len = gdjs.MainCode.GDCloudsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDCloudsObjects2[i].setX(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2);
}
}{for(var i = 0, len = gdjs.MainCode.GDCloudsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDCloudsObjects2[i].setWidth(gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.MainCode.GDCloudsObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDCloudsObjects2[i].setXOffset(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) * 1.2);
}
}}

}


};gdjs.MainCode.eventsList39 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.MainCode.GDScoreTextObjects2);
{for(var i = 0, len = gdjs.MainCode.GDScoreTextObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDScoreTextObjects2[i].setString("Score: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(0)));
}
}}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPortalObjects1Objects = Hashtable.newFrom({"Portal": gdjs.MainCode.GDPortalObjects1});
gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects1});
gdjs.MainCode.eventsList40 = function(runtimeScene) {

{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "door.aac", 0, true, 100, 1);
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.MainCode.GDPortalObjects1);
{gdjs.evtsExt__VolumeFalloff__SetVolumeFalloff.func(runtimeScene, 0, "Sound", gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPortalObjects1Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects1Objects, 0, 20, 750, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.MainCode.eventsList41 = function(runtimeScene) {

{


gdjs.MainCode.eventsList37(runtimeScene);
}


{


gdjs.MainCode.eventsList38(runtimeScene);
}


{


gdjs.MainCode.eventsList39(runtimeScene);
}


{


gdjs.MainCode.eventsList40(runtimeScene);
}


};gdjs.MainCode.eventsList42 = function(runtimeScene) {

{



}


{


gdjs.MainCode.eventsList5(runtimeScene);
}


{


gdjs.MainCode.eventsList16(runtimeScene);
}


{


gdjs.MainCode.eventsList23(runtimeScene);
}


{


gdjs.MainCode.eventsList30(runtimeScene);
}


{


gdjs.MainCode.eventsList36(runtimeScene);
}


{


gdjs.MainCode.eventsList41(runtimeScene);
}


};

gdjs.MainCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MainCode.GDPlayerObjects1.length = 0;
gdjs.MainCode.GDPlayerObjects2.length = 0;
gdjs.MainCode.GDPlayerObjects3.length = 0;
gdjs.MainCode.GDPlayerObjects4.length = 0;
gdjs.MainCode.GDPlayerObjects5.length = 0;
gdjs.MainCode.GDPlayerObjects6.length = 0;
gdjs.MainCode.GDPlatform1Objects1.length = 0;
gdjs.MainCode.GDPlatform1Objects2.length = 0;
gdjs.MainCode.GDPlatform1Objects3.length = 0;
gdjs.MainCode.GDPlatform1Objects4.length = 0;
gdjs.MainCode.GDPlatform1Objects5.length = 0;
gdjs.MainCode.GDPlatform1Objects6.length = 0;
gdjs.MainCode.GDPlatform2Objects1.length = 0;
gdjs.MainCode.GDPlatform2Objects2.length = 0;
gdjs.MainCode.GDPlatform2Objects3.length = 0;
gdjs.MainCode.GDPlatform2Objects4.length = 0;
gdjs.MainCode.GDPlatform2Objects5.length = 0;
gdjs.MainCode.GDPlatform2Objects6.length = 0;
gdjs.MainCode.GDPlatform3Objects1.length = 0;
gdjs.MainCode.GDPlatform3Objects2.length = 0;
gdjs.MainCode.GDPlatform3Objects3.length = 0;
gdjs.MainCode.GDPlatform3Objects4.length = 0;
gdjs.MainCode.GDPlatform3Objects5.length = 0;
gdjs.MainCode.GDPlatform3Objects6.length = 0;
gdjs.MainCode.GDPlatform4Objects1.length = 0;
gdjs.MainCode.GDPlatform4Objects2.length = 0;
gdjs.MainCode.GDPlatform4Objects3.length = 0;
gdjs.MainCode.GDPlatform4Objects4.length = 0;
gdjs.MainCode.GDPlatform4Objects5.length = 0;
gdjs.MainCode.GDPlatform4Objects6.length = 0;
gdjs.MainCode.GDPortalObjects1.length = 0;
gdjs.MainCode.GDPortalObjects2.length = 0;
gdjs.MainCode.GDPortalObjects3.length = 0;
gdjs.MainCode.GDPortalObjects4.length = 0;
gdjs.MainCode.GDPortalObjects5.length = 0;
gdjs.MainCode.GDPortalObjects6.length = 0;
gdjs.MainCode.GDCheckpointObjects1.length = 0;
gdjs.MainCode.GDCheckpointObjects2.length = 0;
gdjs.MainCode.GDCheckpointObjects3.length = 0;
gdjs.MainCode.GDCheckpointObjects4.length = 0;
gdjs.MainCode.GDCheckpointObjects5.length = 0;
gdjs.MainCode.GDCheckpointObjects6.length = 0;
gdjs.MainCode.GDLadderObjects1.length = 0;
gdjs.MainCode.GDLadderObjects2.length = 0;
gdjs.MainCode.GDLadderObjects3.length = 0;
gdjs.MainCode.GDLadderObjects4.length = 0;
gdjs.MainCode.GDLadderObjects5.length = 0;
gdjs.MainCode.GDLadderObjects6.length = 0;
gdjs.MainCode.GDMonsterObjects1.length = 0;
gdjs.MainCode.GDMonsterObjects2.length = 0;
gdjs.MainCode.GDMonsterObjects3.length = 0;
gdjs.MainCode.GDMonsterObjects4.length = 0;
gdjs.MainCode.GDMonsterObjects5.length = 0;
gdjs.MainCode.GDMonsterObjects6.length = 0;
gdjs.MainCode.GDFlyObjects1.length = 0;
gdjs.MainCode.GDFlyObjects2.length = 0;
gdjs.MainCode.GDFlyObjects3.length = 0;
gdjs.MainCode.GDFlyObjects4.length = 0;
gdjs.MainCode.GDFlyObjects5.length = 0;
gdjs.MainCode.GDFlyObjects6.length = 0;
gdjs.MainCode.GDCoinObjects1.length = 0;
gdjs.MainCode.GDCoinObjects2.length = 0;
gdjs.MainCode.GDCoinObjects3.length = 0;
gdjs.MainCode.GDCoinObjects4.length = 0;
gdjs.MainCode.GDCoinObjects5.length = 0;
gdjs.MainCode.GDCoinObjects6.length = 0;
gdjs.MainCode.GDMonsterParticlesObjects1.length = 0;
gdjs.MainCode.GDMonsterParticlesObjects2.length = 0;
gdjs.MainCode.GDMonsterParticlesObjects3.length = 0;
gdjs.MainCode.GDMonsterParticlesObjects4.length = 0;
gdjs.MainCode.GDMonsterParticlesObjects5.length = 0;
gdjs.MainCode.GDMonsterParticlesObjects6.length = 0;
gdjs.MainCode.GDCoinParticlesObjects1.length = 0;
gdjs.MainCode.GDCoinParticlesObjects2.length = 0;
gdjs.MainCode.GDCoinParticlesObjects3.length = 0;
gdjs.MainCode.GDCoinParticlesObjects4.length = 0;
gdjs.MainCode.GDCoinParticlesObjects5.length = 0;
gdjs.MainCode.GDCoinParticlesObjects6.length = 0;
gdjs.MainCode.GDDoorParticlesObjects1.length = 0;
gdjs.MainCode.GDDoorParticlesObjects2.length = 0;
gdjs.MainCode.GDDoorParticlesObjects3.length = 0;
gdjs.MainCode.GDDoorParticlesObjects4.length = 0;
gdjs.MainCode.GDDoorParticlesObjects5.length = 0;
gdjs.MainCode.GDDoorParticlesObjects6.length = 0;
gdjs.MainCode.GDGrassParticleObjects1.length = 0;
gdjs.MainCode.GDGrassParticleObjects2.length = 0;
gdjs.MainCode.GDGrassParticleObjects3.length = 0;
gdjs.MainCode.GDGrassParticleObjects4.length = 0;
gdjs.MainCode.GDGrassParticleObjects5.length = 0;
gdjs.MainCode.GDGrassParticleObjects6.length = 0;
gdjs.MainCode.GDCloudsObjects1.length = 0;
gdjs.MainCode.GDCloudsObjects2.length = 0;
gdjs.MainCode.GDCloudsObjects3.length = 0;
gdjs.MainCode.GDCloudsObjects4.length = 0;
gdjs.MainCode.GDCloudsObjects5.length = 0;
gdjs.MainCode.GDCloudsObjects6.length = 0;
gdjs.MainCode.GDScoreTextObjects1.length = 0;
gdjs.MainCode.GDScoreTextObjects2.length = 0;
gdjs.MainCode.GDScoreTextObjects3.length = 0;
gdjs.MainCode.GDScoreTextObjects4.length = 0;
gdjs.MainCode.GDScoreTextObjects5.length = 0;
gdjs.MainCode.GDScoreTextObjects6.length = 0;
gdjs.MainCode.GDJumpButtonObjects1.length = 0;
gdjs.MainCode.GDJumpButtonObjects2.length = 0;
gdjs.MainCode.GDJumpButtonObjects3.length = 0;
gdjs.MainCode.GDJumpButtonObjects4.length = 0;
gdjs.MainCode.GDJumpButtonObjects5.length = 0;
gdjs.MainCode.GDJumpButtonObjects6.length = 0;
gdjs.MainCode.GDBackgroundPlantsObjects1.length = 0;
gdjs.MainCode.GDBackgroundPlantsObjects2.length = 0;
gdjs.MainCode.GDBackgroundPlantsObjects3.length = 0;
gdjs.MainCode.GDBackgroundPlantsObjects4.length = 0;
gdjs.MainCode.GDBackgroundPlantsObjects5.length = 0;
gdjs.MainCode.GDBackgroundPlantsObjects6.length = 0;
gdjs.MainCode.GDLeftBoundaryObjects1.length = 0;
gdjs.MainCode.GDLeftBoundaryObjects2.length = 0;
gdjs.MainCode.GDLeftBoundaryObjects3.length = 0;
gdjs.MainCode.GDLeftBoundaryObjects4.length = 0;
gdjs.MainCode.GDLeftBoundaryObjects5.length = 0;
gdjs.MainCode.GDLeftBoundaryObjects6.length = 0;
gdjs.MainCode.GDRightBoundaryObjects1.length = 0;
gdjs.MainCode.GDRightBoundaryObjects2.length = 0;
gdjs.MainCode.GDRightBoundaryObjects3.length = 0;
gdjs.MainCode.GDRightBoundaryObjects4.length = 0;
gdjs.MainCode.GDRightBoundaryObjects5.length = 0;
gdjs.MainCode.GDRightBoundaryObjects6.length = 0;
gdjs.MainCode.GDTopBoundaryObjects1.length = 0;
gdjs.MainCode.GDTopBoundaryObjects2.length = 0;
gdjs.MainCode.GDTopBoundaryObjects3.length = 0;
gdjs.MainCode.GDTopBoundaryObjects4.length = 0;
gdjs.MainCode.GDTopBoundaryObjects5.length = 0;
gdjs.MainCode.GDTopBoundaryObjects6.length = 0;
gdjs.MainCode.GDBottomBoundaryObjects1.length = 0;
gdjs.MainCode.GDBottomBoundaryObjects2.length = 0;
gdjs.MainCode.GDBottomBoundaryObjects3.length = 0;
gdjs.MainCode.GDBottomBoundaryObjects4.length = 0;
gdjs.MainCode.GDBottomBoundaryObjects5.length = 0;
gdjs.MainCode.GDBottomBoundaryObjects6.length = 0;
gdjs.MainCode.GDBoundaryJumpThroughObjects1.length = 0;
gdjs.MainCode.GDBoundaryJumpThroughObjects2.length = 0;
gdjs.MainCode.GDBoundaryJumpThroughObjects3.length = 0;
gdjs.MainCode.GDBoundaryJumpThroughObjects4.length = 0;
gdjs.MainCode.GDBoundaryJumpThroughObjects5.length = 0;
gdjs.MainCode.GDBoundaryJumpThroughObjects6.length = 0;
gdjs.MainCode.GDMoonObjects1.length = 0;
gdjs.MainCode.GDMoonObjects2.length = 0;
gdjs.MainCode.GDMoonObjects3.length = 0;
gdjs.MainCode.GDMoonObjects4.length = 0;
gdjs.MainCode.GDMoonObjects5.length = 0;
gdjs.MainCode.GDMoonObjects6.length = 0;
gdjs.MainCode.GDEndScreenBackgroundObjects1.length = 0;
gdjs.MainCode.GDEndScreenBackgroundObjects2.length = 0;
gdjs.MainCode.GDEndScreenBackgroundObjects3.length = 0;
gdjs.MainCode.GDEndScreenBackgroundObjects4.length = 0;
gdjs.MainCode.GDEndScreenBackgroundObjects5.length = 0;
gdjs.MainCode.GDEndScreenBackgroundObjects6.length = 0;
gdjs.MainCode.GDEndScreenHeaderObjects1.length = 0;
gdjs.MainCode.GDEndScreenHeaderObjects2.length = 0;
gdjs.MainCode.GDEndScreenHeaderObjects3.length = 0;
gdjs.MainCode.GDEndScreenHeaderObjects4.length = 0;
gdjs.MainCode.GDEndScreenHeaderObjects5.length = 0;
gdjs.MainCode.GDEndScreenHeaderObjects6.length = 0;
gdjs.MainCode.GDEndScreenSubHeaderObjects1.length = 0;
gdjs.MainCode.GDEndScreenSubHeaderObjects2.length = 0;
gdjs.MainCode.GDEndScreenSubHeaderObjects3.length = 0;
gdjs.MainCode.GDEndScreenSubHeaderObjects4.length = 0;
gdjs.MainCode.GDEndScreenSubHeaderObjects5.length = 0;
gdjs.MainCode.GDEndScreenSubHeaderObjects6.length = 0;
gdjs.MainCode.GDEndScreenBestTextObjects1.length = 0;
gdjs.MainCode.GDEndScreenBestTextObjects2.length = 0;
gdjs.MainCode.GDEndScreenBestTextObjects3.length = 0;
gdjs.MainCode.GDEndScreenBestTextObjects4.length = 0;
gdjs.MainCode.GDEndScreenBestTextObjects5.length = 0;
gdjs.MainCode.GDEndScreenBestTextObjects6.length = 0;
gdjs.MainCode.GDEndScreenChallengeTextObjects1.length = 0;
gdjs.MainCode.GDEndScreenChallengeTextObjects2.length = 0;
gdjs.MainCode.GDEndScreenChallengeTextObjects3.length = 0;
gdjs.MainCode.GDEndScreenChallengeTextObjects4.length = 0;
gdjs.MainCode.GDEndScreenChallengeTextObjects5.length = 0;
gdjs.MainCode.GDEndScreenChallengeTextObjects6.length = 0;
gdjs.MainCode.GDEndScreenRetryTextObjects1.length = 0;
gdjs.MainCode.GDEndScreenRetryTextObjects2.length = 0;
gdjs.MainCode.GDEndScreenRetryTextObjects3.length = 0;
gdjs.MainCode.GDEndScreenRetryTextObjects4.length = 0;
gdjs.MainCode.GDEndScreenRetryTextObjects5.length = 0;
gdjs.MainCode.GDEndScreenRetryTextObjects6.length = 0;
gdjs.MainCode.GDJoystickThumbObjects1.length = 0;
gdjs.MainCode.GDJoystickThumbObjects2.length = 0;
gdjs.MainCode.GDJoystickThumbObjects3.length = 0;
gdjs.MainCode.GDJoystickThumbObjects4.length = 0;
gdjs.MainCode.GDJoystickThumbObjects5.length = 0;
gdjs.MainCode.GDJoystickThumbObjects6.length = 0;
gdjs.MainCode.GDJoystickObjects1.length = 0;
gdjs.MainCode.GDJoystickObjects2.length = 0;
gdjs.MainCode.GDJoystickObjects3.length = 0;
gdjs.MainCode.GDJoystickObjects4.length = 0;
gdjs.MainCode.GDJoystickObjects5.length = 0;
gdjs.MainCode.GDJoystickObjects6.length = 0;

gdjs.MainCode.eventsList42(runtimeScene);
return;

}

gdjs['MainCode'] = gdjs.MainCode;
